import blackjack

print(__name__)
blackjack.play()
print(blackjack.cards)
